// prediction.js

// JSON 파일을 로드하는 함수
async function loadPredictionData() {
    try {
        const response = await fetch('독거노인_우울증_환자수_예측.json');  // JSON 파일 경로
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error loading the prediction data:', error);
    }
}

// 드롭다운에서 선택된 연도를 기반으로 데이터를 필터링하고 차트를 업데이트하는 함수
async function updateChart() {
    const yearSelect = document.getElementById("year-select");
    const selectedYear = yearSelect.value;

    // JSON 파일에서 데이터 로드
    const predictionData = await loadPredictionData();

    // 선택된 연도의 예측 값만 필터링
    const selectedData = predictionData.data.filter(item => item.연도 == selectedYear);

    const labels = selectedData.map(item => item.연도);
    const data = selectedData.map(item => item.독거노인_우울증_수);

    // 차트 업데이트
    const ctx = document.getElementById('predictionChart').getContext('2d');
    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: '독거노인 우울증 환자수',
                data: data,
                fill: false,
                borderColor: 'rgb(75, 192, 192)',
                tension: 0.1
            }]
        }
        
    });
}