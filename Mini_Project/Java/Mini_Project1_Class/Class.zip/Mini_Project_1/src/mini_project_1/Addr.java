package mini_project_1;

public class Addr {
	private String name;
	private String phone;
	private String email;
	private String address;
	private String group;
	
	public Addr(String name, String phone, String email, String address, String group) {
		this.name=name;
		this.phone=phone;
		this.email=email;
		this.address=address;
		this.group=group;
		
		
	}
	public String getPhone() {
		return phone;
		
	}
	public String getName() {
		return name;
	}
	
	public String getEmail() {
		return email;
	}
	
	public String getAddress() {
		return address;
	}
	public String getGroup() {
		return group;
	}
	
	public void setName(String name) {
		this.name=name;

	}
	 public void printInfo() {
	        System.out.println("Name: " + name);
	        System.out.println("Phone: " + phone);
	        System.out.println("Email: " + email);
	        System.out.println("Address: " + address);
	        System.out.println("Group: " + group);
	    }


}