package mini_project_1;

import java.util.Scanner;

public class AddrMain {

	public static void main(String[] args) {
		Addr[] ads = new Addr[5];
			
		Scanner scanner = new Scanner(System.in);
		
		while(true) {
			System.out.println("1. 연락처 저장");
			System.out.println("2. 연락처 출력");
			System.out.println("3. 연락처 수정");
			System.out.println("4. 종료");
			System.out.println("항목을 선택하세요.");
			int choice = scanner.nextInt();
			scanner.nextLine();
			
			if (choice ==1) {
				System.out.println("연락처를 저장합니다.");
				ads[0]= new Addr("배준혁", "01011112222", "naver.com", "인천", "친구");
				ads[1]= new Addr("이대호", "01033334444", "daum.net", "부산", "친구");
				ads[2]= new Addr("손흥민", "01055556666", "google.com", "런던", "가족");
				ads[3]= new Addr("호날두", "01077778888", "lycos.co.kr.com", "포르투갈", "친구");
				ads[4]= new Addr("메시", "01099999999", "nate.com", "아르헨티나", "친구");
			}
			else if(choice ==2) {
				for (Addr ad : ads) {
					System.out.println("Name:"+ad.getName());
					System.out.println("Phone:"+ad.getPhone());
					System.out.println("Email:"+ad.getEmail());
					System.out.println("Address:"+ad.getAddress());
					System.out.println();
				}	}
			else if (choice == 3) {
                System.out.print("수정할 연락처의 이름을 입력하세요: ");
                String nameToEdit = scanner.nextLine();
                
                
                for (Addr ad : ads) {
                    if (ad.getName().equals(nameToEdit)) { 

                        System.out.println("현재 연락처 정보:");
                        ad.printInfo();
                        

                        System.out.print("새로운 이름을 입력하세요 (Enter를 누르면 변경하지 않음): ");
                        String newName = scanner.nextLine();
                        if (!newName.equals("")) ad.setName(newName); 


                        System.out.println("수정된 연락처 정보:");
                        ad.printInfo();
                        break;
                    }
                }


            } else if (choice == 4) {
                System.out.println("프로그램을 종료합니다.");
                break;
            }
        }
        scanner.close();
    }
}