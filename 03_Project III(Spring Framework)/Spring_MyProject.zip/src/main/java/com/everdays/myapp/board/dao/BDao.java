package com.everdays.myapp.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import com.everdays.myapp.board.dto.BDto;

public class BDao {
    DataSource dataSource;

    public BDao() {
        try {
            Context context = new InitialContext();
            dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void write(String bName, String bTitle, String bContent) {
        try (Connection connection = dataSource.getConnection();
             PreparedStatement ps = connection.prepareStatement(
                "INSERT INTO mvc_board (bId, bName, bTitle, bContent, bHit, bGroup, bStep, bIndent) " +
                "VALUES (mvc_board_seq.nextval, ?, ?, ?, 0, mvc_board_seq.currval, 0, 0)");) {

            ps.setString(1, bName);
            ps.setString(2, bTitle);
            ps.setString(3, bContent);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<BDto> list() {
        ArrayList<BDto> dtos = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM mvc_board WHERE bStep = 0 ORDER BY bGroup DESC, bStep ASC");
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                dtos.add(extractDto(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dtos;
    }

    public ArrayList<BDto> list(int startRow, int itemsPerPage) {
        ArrayList<BDto> dtos = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                 "SELECT * FROM (SELECT ROWNUM rnum, A.* FROM (SELECT * FROM mvc_board WHERE bStep = 0 ORDER BY bGroup DESC, bStep ASC) A WHERE ROWNUM <= ?) WHERE rnum > ?")) {

            ps.setInt(1, startRow + itemsPerPage);
            ps.setInt(2, startRow);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    dtos.add(extractDto(rs));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dtos;
    }

    public int getTotalCount() {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM mvc_board WHERE bStep = 0");
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) return rs.getInt(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public ArrayList<BDto> getReplies(int groupId) {
        ArrayList<BDto> replies = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM mvc_board WHERE bGroup = ? AND bStep > 0 ORDER BY bStep ASC")) {

            ps.setInt(1, groupId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    replies.add(extractDto(rs));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return replies;
    }

    public BDto contentView(String strID) {
        upHit(strID);
        BDto dto = null;
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM mvc_board WHERE bId = ?")) {

            ps.setInt(1, Integer.parseInt(strID));
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) dto = extractDto(rs);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dto;
    }

    public void reply(String bId, String bName, String bTitle, String bContent, int bGroup, int bStep, int bIndent) {
        replyShape(bGroup, bStep);
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO mvc_board (bId, bName, bTitle, bContent, bGroup, bStep, bIndent) VALUES (mvc_board_seq.nextval, ?, ?, ?, ?, ?, ?)");) {

            ps.setString(1, bName);
            ps.setString(2, bTitle);
            ps.setString(3, bContent);
            ps.setInt(4, bGroup);
            ps.setInt(5, bStep + 1);
            ps.setInt(6, bIndent + 1);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void replyModify(String bId, String bContent) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement("UPDATE mvc_board SET bContent = ? WHERE bId = ?")) {

            ps.setString(1, bContent);
            ps.setInt(2, Integer.parseInt(bId));
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void modify(String bId, String bName, String bTitle, String bContent) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement("UPDATE mvc_board SET bName = ?, bTitle = ?, bContent = ? WHERE bId = ?")) {

            ps.setString(1, bName);
            ps.setString(2, bTitle);
            ps.setString(3, bContent);
            ps.setInt(4, Integer.parseInt(bId));
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void delete(String bId) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM mvc_board WHERE bId = ?")) {

            ps.setInt(1, Integer.parseInt(bId));
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void replyShape(int bGroup, int bStep) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement("UPDATE mvc_board SET bStep = bStep + 1 WHERE bGroup = ? AND bStep > ?")) {

            ps.setInt(1, bGroup);
            ps.setInt(2, bStep);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void upHit(String bId) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement("UPDATE mvc_board SET bHit = bHit + 1 WHERE bId = ?")) {

            ps.setString(1, bId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private BDto extractDto(ResultSet rs) throws Exception {
        return new BDto(
            rs.getInt("bId"),
            rs.getString("bName"),
            rs.getString("bTitle"),
            rs.getString("bContent"),
            rs.getTimestamp("bDate"),
            rs.getInt("bHit"),
            rs.getInt("bGroup"),
            rs.getInt("bStep"),
            rs.getInt("bIndent")
        );
    }

    private void close(Connection conn, PreparedStatement pstmt, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
