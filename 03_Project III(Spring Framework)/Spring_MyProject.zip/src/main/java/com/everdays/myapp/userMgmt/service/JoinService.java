package com.everdays.myapp.userMgmt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;
import java.util.regex.Pattern;

import com.everdays.myapp.userMgmt.dao.IUserMgmtDao;
import com.everdays.myapp.userMgmt.dto.UserMgmtDto;

@Service
public class JoinService {

    @Autowired
    private IUserMgmtDao dao;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    public String execute(Model model) {
        Map<String, Object> map = model.asMap();
        HttpServletRequest request = (HttpServletRequest) map.get("request");

        String userId = request.getParameter("username");
        String rawPassword = request.getParameter("password1");
        String confirmPassword = request.getParameter("password2");
        String name = request.getParameter("name");
        String phone = request.getParameter("phone1") + "-" +
                       request.getParameter("phone2") + "-" +
                       request.getParameter("phone3");
        String email = request.getParameter("email");

        if (!rawPassword.equals(confirmPassword)) {
            model.addAttribute("joinError", "��й�ȣ�� Ȯ�����ּ���.");
            return "userMgmt/signup";
        }

        if (!isValidPassword(rawPassword)) {
            model.addAttribute("joinError", "��й�ȣ�� 10~14�� ����, ����, Ư������ �����̾�� �մϴ�.");
            return "userMgmt/signup";
        }

        if (dao.countByUserId(userId) > 0) {
            model.addAttribute("joinError", "�̹� ��� ���� ���̵��Դϴ�.");
            return "userMgmt/signup";
        }
        if (dao.countByName(name) > 0) {
            model.addAttribute("joinError", "�̹� ��ϵ� �̸��Դϴ�.");
            return "userMgmt/signup";
        }
        if (dao.countByPhone(phone) > 0) {
            model.addAttribute("joinError", "�̹� ��ϵ� ��ȭ��ȣ�Դϴ�.");
            return "userMgmt/signup";
        }
        if (dao.countByEmail(email) > 0) {
            model.addAttribute("joinError", "�̹� ��ϵ� �̸����Դϴ�.");
            return "userMgmt/signup";
        }

        String hashedPassword = passwordEncoder.encode(rawPassword);

        UserMgmtDto user = new UserMgmtDto();
        user.setUserId(userId);
        user.setPassword(hashedPassword);
        user.setName(name);
        user.setPhone(phone);
        user.setEmail(email);

        dao.join(user);
        return "redirect:/userMgmt/login";
    }

    private boolean isValidPassword(String password) {
        if (password == null || password.length() < 10 || password.length() > 14) return false;
        boolean hasLetter = Pattern.compile("[a-zA-Z]").matcher(password).find();
        boolean hasDigit = Pattern.compile("[0-9]").matcher(password).find();
        boolean hasSpecial = Pattern.compile("[^a-zA-Z0-9]").matcher(password).find();
        return hasLetter && hasDigit && hasSpecial;
    }
}
