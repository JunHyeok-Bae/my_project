package com.everdays.myapp;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class IntroController {

    // intro.jsp�� �̵�
    @GetMapping("/intro")
    public String showIntroPage() {
        return "intro"; 
    }
}
