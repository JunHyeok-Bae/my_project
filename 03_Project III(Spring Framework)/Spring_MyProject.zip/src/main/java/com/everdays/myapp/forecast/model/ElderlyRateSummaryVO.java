package com.everdays.myapp.forecast.model;

public class ElderlyRateSummaryVO {
    
    private int year;
    private double elderlyPopulation;      // �� ���� �α�
    private double livingAloneElderly;       // ���ų��� �α�
    private double rate;                     // (���ų��� �α� / �� ���� �α�) * 100

    public ElderlyRateSummaryVO() { }

    public ElderlyRateSummaryVO(int year, double elderlyPopulation, double livingAloneElderly, double rate) {
        this.year = year;
        this.elderlyPopulation = elderlyPopulation;
        this.livingAloneElderly = livingAloneElderly;
        this.rate = rate;
    }

    public int getYear() {
        return year;
    }
    public void setYear(int year) {
        this.year = year;
    }
    public double getElderlyPopulation() {
        return elderlyPopulation;
    }
    public void setElderlyPopulation(double elderlyPopulation) {
        this.elderlyPopulation = elderlyPopulation;
    }
    public double getLivingAloneElderly() {
        return livingAloneElderly;
    }
    public void setLivingAloneElderly(double livingAloneElderly) {
        this.livingAloneElderly = livingAloneElderly;
    }
    public double getRate() {
        return rate;
    }
    public void setRate(double rate) {
        this.rate = rate;
    }
    
    @Override
    public String toString() {
        return "ElderlyRateSummaryVO{" +
               "year=" + year +
               ", elderlyPopulation=" + elderlyPopulation +
               ", livingAloneElderly=" + livingAloneElderly +
               ", rate=" + rate +
               '}';
    }
}

