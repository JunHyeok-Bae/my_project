package com.everdays.myapp.forecast.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.everdays.myapp.forecast.model.ElderlyRateSummaryVO;

@Repository
public class ElderlyRateDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    // ���� ������ �����͸� ��ȸ�Ͽ�, �� ���� �α��� ���ų��� �α��� �������� ������ ���
    public ElderlyRateSummaryVO getElderlyRateDataByYear(int year) {
        String sql = "SELECT year, elderly_population, living_alone_elderly " +
                     "FROM Data WHERE year = ?";
        return jdbcTemplate.queryForObject(sql, new Object[]{year}, new RowMapper<ElderlyRateSummaryVO>() {
            @Override
            public ElderlyRateSummaryVO mapRow(ResultSet rs, int rowNum) throws SQLException {
                int yr = rs.getInt("year");
                double total = rs.getDouble("elderly_population");
                double alone = rs.getDouble("living_alone_elderly");
                double rate = (total != 0) ? (alone / total) * 100 : 0.0;
                return new ElderlyRateSummaryVO(yr, total, alone, rate);
            }
        });
    }
}
