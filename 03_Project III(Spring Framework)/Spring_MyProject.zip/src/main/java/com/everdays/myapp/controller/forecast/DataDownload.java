package com.everdays.myapp.controller.forecast;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.everdays.myapp.forecast.model.DepressionVO;
import com.everdays.myapp.forecast.model.ElderlyRateSummaryVO;
import com.everdays.myapp.forecast.model.PopulationVO;
import com.everdays.myapp.forecast.service.DepressionService;
import com.everdays.myapp.forecast.service.ElderlyRateService;
import com.everdays.myapp.forecast.service.PopulationService;

@Controller
public class DataDownload {

    @Autowired
    private PopulationService populationService;

    @GetMapping("/forecast/population/download")
    public void downloadPopulationData(
            @RequestParam(required = false, defaultValue = "2025") int startYear,
            @RequestParam(required = false, defaultValue = "2070") int endYear,
            @RequestParam(required = false) List<String> regions,
            HttpServletResponse response) throws Exception {

        // �⺻�� ó��: �Ķ���Ͱ� ���ų� �� ��� "����"�� �⺻���� ���
        if (regions == null || regions.isEmpty()) {
            regions = new ArrayList<String>();
            regions.add("����");
        }

        // Population �����͸� ������
        List<PopulationVO> populationDataList = populationService.getPopulationData(startYear, endYear, regions);
        
     // --- ���� �ڵ� �߰� --- //
        Collections.sort(populationDataList, new Comparator<PopulationVO>() {
            @Override
            public int compare(PopulationVO o1, PopulationVO o2) {
                int cmp = o1.getRegion().compareTo(o2.getRegion());
                if (cmp == 0) {
                    cmp = Integer.valueOf(o1.getYear()).compareTo(Integer.valueOf(o2.getYear()));
                }
                return cmp;
            }
        });

        
     // CSV ���� �ٿ�ε� ���� ��� ����
        response.setContentType("text/csv;charset=UTF-8");
        response.setHeader("Content-Disposition", "attachment; filename=\"population_data.csv\"");

        PrintWriter writer = response.getWriter();
        // UTF-8 BOM �߰�
        writer.write("\uFEFF");

        // CSV ��� ���
        writer.println("����,����,�α� ��");
        for (PopulationVO vo : populationDataList) {
            writer.println(vo.getYear() + "," + vo.getRegion() + "," + vo.getPopulation());
        }
        writer.flush();
        writer.close();
    }
    
    @Autowired
    private DepressionService depressionService;
    
 // ����� ������ CSV �ٿ�ε� ��������Ʈ
    @GetMapping("/forecast/depression/download")
    public void downloadDepressionData(
            @RequestParam(required = false, defaultValue = "2025") int startYear,
            @RequestParam(required = false, defaultValue = "2070") int endYear,
            HttpServletResponse response) throws Exception {
        
        List<DepressionVO> depressionDataList = depressionService.getDepressionDataByYearRange(startYear, endYear);
        
        response.setContentType("text/csv;charset=UTF-8");
        response.setHeader("Content-Disposition", "attachment; filename=\"depression_data.csv\"");
        
        PrintWriter writer = response.getWriter();
        // UTF-8 BOM �߰� (�ѱ� ���� ����)
        writer.write("\uFEFF");
        // CSV ���
        writer.println("����,����� ȯ�� �� ����");
        // ������ �� ���
        for (DepressionVO vo : depressionDataList) {
            writer.println(vo.getYear() + "," + vo.getElderDepression());
        }
        writer.flush();
        writer.close();
    }
    
    @Autowired
    private ElderlyRateService elderlyRateService;
    
    @GetMapping("/forecast/depression/doughnutDownload")
    public void downloadDoughnutData(
            @RequestParam(required = false, defaultValue = "2000") int year,
            HttpServletResponse response) throws Exception {
        
        // �ش� ������ ���ų��� ������ ��ȸ (ElderlyRateSummaryVO)
        ElderlyRateSummaryVO summary = elderlyRateService.getElderlyRateDataByYear(year);
        
        // CSV ���� ��� ���� (UTF-8 BOM ����)
        response.setContentType("text/csv;charset=UTF-8");
        response.setHeader("Content-Disposition", "attachment; filename=\"doughnut_data_" + year + ".csv\"");
        
        PrintWriter writer = response.getWriter();
        // UTF-8 BOM �߰� (�ѱ� ���� ����)
        writer.write("\uFEFF");
        
        // CSV ��� �ۼ�
        writer.println("����,���� �α� ��,���ų��� �α� ��,���ų��� ����");
        
        // CSV ������ �� �ۼ�
        writer.println(summary.getYear() + "," 
                + summary.getElderlyPopulation() + "," 
                + summary.getLivingAloneElderly() + "," 
                + summary.getRate());
        
        writer.flush();
        writer.close();
    }
}


