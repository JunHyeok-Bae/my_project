package com.everdays.myapp.controller.userMgmt;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.everdays.myapp.userMgmt.dto.UserMgmtDto;
import com.everdays.myapp.userMgmt.service.FindIdByEmailService;
import com.everdays.myapp.userMgmt.service.FindIdByPhoneService;
import com.everdays.myapp.userMgmt.service.FindPwByEmailService;
import com.everdays.myapp.userMgmt.service.FindPwByPhoneService;
import com.everdays.myapp.userMgmt.service.IUserMgmtService;
import com.everdays.myapp.userMgmt.service.JoinService;
import com.everdays.myapp.userMgmt.service.LoginService;
import com.everdays.myapp.userMgmt.service.UpdatePasswordService;

@Controller
@RequestMapping("/userMgmt")
public class UserMgmtController {

    @Autowired
    private LoginService loginService;

    @Autowired
    private JoinService joinService;

    @Autowired
    private FindIdByEmailService findIdByEmailService;

    @Autowired
    private FindIdByPhoneService findIdByPhoneService;

    @Autowired
    private FindPwByEmailService findPwByEmailService;

    @Autowired
    private FindPwByPhoneService findPwByPhoneService;

    @Autowired
    private UpdatePasswordService updatePasswordService;

    // �α��� ��
    @GetMapping("/login")
    public String loginForm() {
        return "userMgmt/loginForm";
    }

    // �α��� ó��
    @PostMapping("/login")
    public String login(@RequestParam("userId") String userId,
                        @RequestParam("password") String password,
                        HttpServletRequest request,
                        Model model) {

        int result = loginService.loginCheck(userId, password);

        if (result == IUserMgmtService.USER_LOGIN_SUCCESS) {
            UserMgmtDto user = loginService.getUser(userId);
            request.getSession().setAttribute("user", user);
            return "redirect:/";
        }

        model.addAttribute("error", "���̵� �Ǵ� ��й�ȣ�� Ʋ�Ƚ��ϴ�.");
        return "userMgmt/loginForm";
    }

    // ȸ������ ��
    @GetMapping("/signup")
    public String signupForm() {
        return "userMgmt/signup";
    }

    @PostMapping("/join")
    public String join(Model model, HttpServletRequest request, RedirectAttributes redirectAttributes) {
        model.addAttribute("request", request);
        String view = joinService.execute(model); // ���񽺰� forward/redirect �Ǵ�
        if (view.startsWith("redirect:")) {
            redirectAttributes.addFlashAttribute("successMessage", "ȸ�������� �Ϸ�Ǿ����ϴ�!");
        }
        return view;
    }

    // ���̵� ã�� ��
    @GetMapping("/find_username")
    public String findIdForm() {
        return "userMgmt/findIdForm";
    }

    // ���̵� ã�� ó��
    @PostMapping("/findId")
    public String findId(HttpServletRequest request, Model model) {
        String name = request.getParameter("name");
        String authType = request.getParameter("authType");

        UserMgmtDto user = null;

        if ("email".equals(authType)) {
            String email = request.getParameter("email");
            user = findIdByEmailService.findIdByEmail(name, email);
        } else if ("phone".equals(authType)) {
            String phone = request.getParameter("phone1") + "-" +
                           request.getParameter("phone2") + "-" +
                           request.getParameter("phone3");
            user = findIdByPhoneService.findIdByPhone(name, phone);
        }

        model.addAttribute("userId", user != null ? user.getUserId() : null);
        return "userMgmt/findIdResult";
    }

    // ��й�ȣ ã�� ��
    @GetMapping("/find_password")
    public String findPwForm() {
        return "userMgmt/findPwForm";
    }

    // ��й�ȣ ã��
    @PostMapping("/findPw")
    public String findPw(HttpServletRequest request, Model model) {
        String userId = request.getParameter("userId");
        String name = request.getParameter("name");
        String authType = request.getParameter("authType");

        UserMgmtDto user = null;

        if ("email".equals(authType)) {
            String email = request.getParameter("email");
            user = findPwByEmailService.findPwByEmail(userId, name, email);
        } else if ("phone".equals(authType)) {
            String phone = request.getParameter("phone1") + "-" +
                           request.getParameter("phone2") + "-" +
                           request.getParameter("phone3");
            user = findPwByPhoneService.findPwByPhone(userId, name, phone);
        }

        model.addAttribute("userId", user != null ? user.getUserId() : null);
        return "userMgmt/findPwResult";
    }

    // ��й�ȣ ���� ó��
    @PostMapping("/updatePassword")
    public String updatePassword(@RequestParam("userId") String userId,
                                 @RequestParam("newPassword") String newPassword,
                                 Model model) {
        updatePasswordService.updatePassword(userId, newPassword);
        return "redirect:/userMgmt/login";
    }

    // �α׾ƿ�
    @GetMapping("/logout")
    public String logout(HttpServletRequest request) {
        request.getSession().invalidate();
        return "redirect:/";
    }
}
