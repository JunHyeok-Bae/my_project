package com.everdays.myapp.board.service;

import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.ui.Model;
import com.everdays.myapp.board.dao.BDao;
import com.everdays.myapp.userMgmt.dto.UserMgmtDto;

public class BWriteService implements BService {

    @Override
    public void execute(Model model) {
        Map<String, Object> map = model.asMap();
        HttpServletRequest request = (HttpServletRequest) map.get("request");

        UserMgmtDto user = (UserMgmtDto) request.getSession().getAttribute("user");
        if (user == null) return;

        String bName = user.getUserId(); // �α��ε� ������ ���̵�� �۾��� ����
        String bTitle = request.getParameter("bTitle");
        String bContent = request.getParameter("bContent");

        BDao dao = new BDao();
        dao.write(bName, bTitle, bContent);
    }
}
