package com.everdays.myapp.forecast.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.everdays.myapp.forecast.dao.PopulationDAO;
import com.everdays.myapp.forecast.model.PopulationVO;

@Service
public class PopulationService {

    @Autowired
    private PopulationDAO populationDAO;

    // DAO���� ��ȸ�� �����͸� PopulationVO�� ����
    public List<PopulationVO> getPopulationData(int startYear, int endYear, List<String> regions) {
        List<Map<String, Object>> list = populationDAO.getPopulationData(startYear, endYear, regions);
        List<PopulationVO> result = new ArrayList<PopulationVO>();
        for (Map<String, Object> row : list) {
            PopulationVO vo = new PopulationVO();
            vo.setYear(((Number) row.get("year")).intValue());
            vo.setRegion((String) row.get("region"));
            vo.setPopulation(((Number) row.get("population")).doubleValue());
            result.add(vo);
        }
        return result;
    }
}
