package com.everdays.myapp.userMgmt.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.everdays.myapp.userMgmt.dto.UserMgmtDto;

@Repository
public class UserMgmtDao implements IUserMgmtDao {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public void join(UserMgmtDto user) {
        String sql = "INSERT INTO USERS (USER_ID, PASSWORD, NAME, PHONE, EMAIL) VALUES (?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql,
                user.getUserId(),
                user.getPassword(),
                user.getName(),
                user.getPhone(),
                user.getEmail());
    }

    @Override
    public int loginCheck(String userId, String password) {
        String sql = "SELECT PASSWORD FROM USERS WHERE USER_ID = ?";
        try {
            String dbPassword = jdbcTemplate.queryForObject(sql, new Object[]{userId}, String.class);
            if (dbPassword != null && dbPassword.equals(password)) {
                return USER_LOGIN_SUCCESS;
            } else {
                return USER_LOGIN_FAIL;
            }
        } catch (Exception e) {
            return USER_NOT_FOUND;
        }
    }

    @Override
    public UserMgmtDto findIdByEmail(String name, String email) {
        String sql = "SELECT * FROM USERS WHERE NAME = ? AND EMAIL = ?";
        List<UserMgmtDto> result = jdbcTemplate.query(sql, new Object[]{name, email},
                new BeanPropertyRowMapper<UserMgmtDto>(UserMgmtDto.class));
        return result.isEmpty() ? null : result.get(0);
    }

    @Override
    public UserMgmtDto findIdByPhone(String name, String phone) {
        String sql = "SELECT * FROM USERS WHERE NAME = ? AND PHONE = ?";
        List<UserMgmtDto> result = jdbcTemplate.query(sql, new Object[]{name, phone},
                new BeanPropertyRowMapper<UserMgmtDto>(UserMgmtDto.class));
        return result.isEmpty() ? null : result.get(0);
    }

    @Override
    public UserMgmtDto findPwByEmail(String userId, String name, String email) {
        String sql = "SELECT * FROM USERS WHERE USER_ID = ? AND NAME = ? AND EMAIL = ?";
        List<UserMgmtDto> result = jdbcTemplate.query(sql, new Object[]{userId, name, email},
                new BeanPropertyRowMapper<UserMgmtDto>(UserMgmtDto.class));
        return result.isEmpty() ? null : result.get(0);
    }

    @Override
    public UserMgmtDto findPwByPhone(String userId, String name, String phone) {
        String sql = "SELECT * FROM USERS WHERE USER_ID = ? AND NAME = ? AND PHONE = ?";
        List<UserMgmtDto> result = jdbcTemplate.query(sql, new Object[]{userId, name, phone},
                new BeanPropertyRowMapper<UserMgmtDto>(UserMgmtDto.class));
        return result.isEmpty() ? null : result.get(0);
    }

    @Override
    public void updatePassword(String userId, String newPassword) {
        String sql = "UPDATE USERS SET PASSWORD = ? WHERE USER_ID = ?";
        jdbcTemplate.update(sql, newPassword, userId);
    }

    @Override
    public UserMgmtDto getMember(String userId) {
        String sql = "SELECT * FROM USERS WHERE USER_ID = ?";
        List<UserMgmtDto> result = jdbcTemplate.query(sql, new Object[]{userId},
                new BeanPropertyRowMapper<UserMgmtDto>(UserMgmtDto.class));
        return result.isEmpty() ? null : result.get(0);
    }

    // 🚨 중복 검사 로직 추가
    @Override
    public int countByUserId(String userId) {
        String sql = "SELECT COUNT(*) FROM USERS WHERE USER_ID = ?";
        return jdbcTemplate.queryForObject(sql, new Object[]{userId}, Integer.class);
    }

    @Override
    public int countByName(String name) {
        String sql = "SELECT COUNT(*) FROM USERS WHERE NAME = ?";
        return jdbcTemplate.queryForObject(sql, new Object[]{name}, Integer.class);
    }

    @Override
    public int countByPhone(String phone) {
        String sql = "SELECT COUNT(*) FROM USERS WHERE PHONE = ?";
        return jdbcTemplate.queryForObject(sql, new Object[]{phone}, Integer.class);
    }

    @Override
    public int countByEmail(String email) {
        String sql = "SELECT COUNT(*) FROM USERS WHERE EMAIL = ?";
        return jdbcTemplate.queryForObject(sql, new Object[]{email}, Integer.class);
    }
}
