package com.everdays.myapp.board.service;

import java.util.Map;
import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.everdays.myapp.board.dao.BDao;

public class BReplyService implements BService {

    @Override
    public void execute(Model model) {
        Map<String, Object> map = model.asMap();
        HttpServletRequest request = (HttpServletRequest) map.get("request");

        String bName = request.getParameter("bName");
        String bContent = request.getParameter("bContent");

        int bGroup = Integer.parseInt(request.getParameter("bGroup"));
        int bStep = Integer.parseInt(request.getParameter("bStep"));
        int bIndent = Integer.parseInt(request.getParameter("bIndent"));

        String originalTitle = request.getParameter("bTitle");
        String bTitle = (originalTitle != null && !originalTitle.trim().isEmpty())
                ? "RE: " + originalTitle
                : "RE: (���� ����)";

        BDao dao = new BDao();
        dao.reply(null, bName, bTitle, bContent, bGroup, bStep, bIndent);
    }
}
