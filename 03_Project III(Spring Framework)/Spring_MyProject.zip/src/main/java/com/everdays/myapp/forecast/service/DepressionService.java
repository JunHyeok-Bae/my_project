package com.everdays.myapp.forecast.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.everdays.myapp.forecast.model.DepressionVO;

@Service
public class DepressionService {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public DepressionService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<DepressionVO> getDepressionDataByYearRange(int startYear, int endYear) {
        String sql = "SELECT Year, Elder_depression FROM DEPRESSION WHERE Year BETWEEN ? AND ?";
        
        // ������ ��ȸ
        return jdbcTemplate.query(sql, new Object[]{startYear, endYear}, new RowMapper<DepressionVO>() {
            @Override
            public DepressionVO mapRow(ResultSet rs, int rowNum) throws SQLException {
                DepressionVO depressionVO = new DepressionVO();
                depressionVO.setYear(rs.getInt("Year"));
                depressionVO.setElderDepression(rs.getDouble("Elder_depression"));
                return depressionVO;
            }
        });
    }
}
