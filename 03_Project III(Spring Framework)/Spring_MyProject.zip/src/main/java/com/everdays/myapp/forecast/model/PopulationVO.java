package com.everdays.myapp.forecast.model;

public class PopulationVO {
    
    private int year;          // forecast_population ���̺��� year �÷�
    private String region;     // forecast_population ���̺��� region �÷�
    private double population; // forecast_population ���̺��� population �÷�

    public PopulationVO() {}

    public PopulationVO(int year, String region, double population) {
        this.year = year;
        this.region = region;
        this.population = population;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public double getPopulation() {
        return population;
    }

    public void setPopulation(double population) {
        this.population = population;
    }

    @Override
    public String toString() {
        return "PopulationVO{" +
               "year=" + year +
               ", region='" + region + '\'' +
               ", population=" + population +
               '}';
    }
}
