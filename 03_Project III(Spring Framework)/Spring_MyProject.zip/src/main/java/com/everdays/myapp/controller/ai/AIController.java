package com.everdays.myapp.controller.ai;

import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.*;

@Controller
public class AIController {

    private final String FLASK_URL = "http://192.168.42.8:8000";

    private String postToFlask(String endpoint, JSONObject json) {
        RestTemplate restTemplate = new RestTemplate();

        // �ѱ� ���ڵ��� ���� UTF-8 �޽��� ������ �߰�
        restTemplate.getMessageConverters().add(0,
            new StringHttpMessageConverter(StandardCharsets.UTF_8));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> request = new HttpEntity<>(json.toString(), headers);

        try {
            ResponseEntity<String> response = restTemplate.postForEntity(
                FLASK_URL + endpoint, request, String.class);
            return response.getBody();
        } catch (Exception e) {
            e.printStackTrace();
            return "���� �߻�: " + e.getMessage();
        }
    }

    private List<String[]> buildChatHistory(String jsonHistory, String prompt, String response) {
        List<String[]> history = new ArrayList<>();
        if (jsonHistory != null && !jsonHistory.isEmpty()) {
            JSONArray arr = new JSONArray(jsonHistory);
            for (int i = 0; i < arr.length(); i++) {
                JSONArray pair = arr.getJSONArray(i);
                history.add(new String[]{pair.getString(0), pair.getString(1)});
            }
        }
        history.add(new String[]{prompt, response});
        return history;
    }

    // 1. �ؽ�Ʈ ����
    @GetMapping("/generate")
    public String showGeneratePage(Model model) {
        model.addAttribute("chatHistory", new ArrayList<String[]>());
        return "generate";
    }

    @PostMapping("/generate")
    public String generate(@RequestParam("prompt") String prompt,
                           @RequestParam(value = "chatHistoryJson", required = false) String chatHistoryJson,
                           Model model) {
        JSONObject json = new JSONObject();
        json.put("prompt", prompt);

        String result = "���� ����";
        try {
            String raw = postToFlask("/generate", json);
            JSONArray arr = new JSONArray(raw);
            JSONObject obj = arr.getJSONObject(0);
            result = obj.getString("generated_text");
        } catch (Exception e) {
            e.printStackTrace();
        }

        model.addAttribute("chatHistory", buildChatHistory(chatHistoryJson, prompt, result));
        return "generate";
    }

    // 2. ����
    @GetMapping("/translate")
    public String showTranslatePage(Model model) {
        model.addAttribute("chatHistory", new ArrayList<String[]>());
        return "translate";
    }

    @PostMapping("/translate")
    public String translate(@RequestParam("text") String text,
                            @RequestParam("src_lang") String srcLang,
                            @RequestParam("tgt_lang") String tgtLang,
                            @RequestParam(value = "chatHistoryJson", required = false) String chatHistoryJson,
                            Model model) {

        System.out.println("���� ��û: text=" + text + ", src=" + srcLang + ", tgt=" + tgtLang);

        JSONObject json = new JSONObject();
        json.put("text", text);
        json.put("src_lang", srcLang);
        json.put("tgt_lang", tgtLang);

        String result = "���� ����";
        try {
            String raw = postToFlask("/translate", json);
            System.out.println("Flask ����: " + raw);
            JSONArray arr = new JSONArray(raw);
            JSONObject obj = arr.getJSONObject(0);
            result = obj.getString("translation_text");
        } catch (Exception e) {
            e.printStackTrace();
        }

        String prompt = String.format("[%s �� %s] %s", srcLang, tgtLang, text);
        model.addAttribute("src_lang", srcLang);
        model.addAttribute("tgt_lang", tgtLang);
        model.addAttribute("chatHistory", buildChatHistory(chatHistoryJson, prompt, result));
        return "translate";
    }

    // 3. ���� �м�
    @GetMapping("/sentiment")
    public String showSentimentPage(Model model) {
        model.addAttribute("chatHistory", new ArrayList<String[]>());
        return "sentiment";
    }

    @PostMapping("/sentiment")
    public String sentiment(@RequestParam("text") String text,
                            @RequestParam(value = "chatHistoryJson", required = false) String chatHistoryJson,
                            Model model) {
        JSONObject json = new JSONObject();
        json.put("text", text);

        String result = "���� �м� ����";
        try {
            String raw = postToFlask("/sentiment", json);
            JSONArray arr = new JSONArray(raw);
            JSONObject obj = arr.getJSONObject(0);

            String label = obj.getString("label");  // positive / negative
            double score = obj.getDouble("score");

            String sentiment = label.equalsIgnoreCase("positive") ? "����" : "����";
            result = String.format("\"%s\" �����Դϴ�.", sentiment);

        } catch (Exception e) {
            e.printStackTrace();
        }

        model.addAttribute("chatHistory", buildChatHistory(chatHistoryJson, text, result));
        return "sentiment";
    }

    // 4. ��ü�� �ν� (NER)
    @GetMapping("/ner")
    public String showNERPage(Model model) {
        model.addAttribute("chatHistory", new ArrayList<String[]>());
        return "ner";
    }

    @PostMapping("/ner")
    public String ner(@RequestParam("text") String text,
                      @RequestParam(value = "chatHistoryJson", required = false) String chatHistoryJson,
                      Model model) {
        JSONObject json = new JSONObject();
        json.put("text", text);

        StringBuilder result = new StringBuilder();
        Map<String, String> labelMap = new HashMap<>();
        labelMap.put("PERSON", "���");
        labelMap.put("LOCATION", "����");
        labelMap.put("DATE", "��¥");
        labelMap.put("TIME", "�ð�");
        labelMap.put("ORGANIZATION", "����");
        labelMap.put("EVENT", "�̺�Ʈ");
        labelMap.put("ARTIFACTS", "�ΰ���");
        labelMap.put("QUANTITY", "����");
        labelMap.put("TERM", "���");
        labelMap.put("THEORY", "�̷�");
        labelMap.put("STUDY_FIELD", "�й� �о�");
        labelMap.put("PLANT", "�Ĺ�");
        labelMap.put("ANIMAL", "����");
        labelMap.put("CIVILIZATION", "����");
        labelMap.put("MATERIAL", "����");

        try {
            String raw = postToFlask("/ner", json);
            System.out.println("[ner] rawResult = " + raw);

            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject ent = arr.getJSONObject(i);
                String word = ent.getString("text");
                String label = ent.getString("label");
                String labelKor = labelMap.getOrDefault(label, label);
                result.append("- ").append(word).append(" (").append(labelKor).append(")\n");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        model.addAttribute("chatHistory", buildChatHistory(chatHistoryJson, text, result.toString()));
        return "ner";
    }
}
