package com.everdays.myapp.board.dto;

import java.sql.Timestamp;

public class BDto {

    private int bId;
    private String bName;
    private String bTitle;
    private String bContent;
    private Timestamp bDate;
    private int bHit;
    private int bGroup;
    private int bStep;
    private int bIndent;

    public BDto() {
    }

    public BDto(int bId, String bName, String bTitle, String bContent, Timestamp bDate,
                int bHit, int bGroup, int bStep, int bIndent) {
        this.bId = bId;
        this.bName = bName;
        this.bTitle = bTitle;
        this.bContent = bContent;
        this.bDate = bDate;
        this.bHit = bHit;
        this.bGroup = bGroup;
        this.bStep = bStep;
        this.bIndent = bIndent;
    }

    // ==== Getter / Setter (ǥ�� JavaBeans ���) ====

    public int getBId() {
        return bId;
    }

    public void setBId(int bId) {
        this.bId = bId;
    }

    public String getBName() {
        return bName;
    }

    public void setBName(String bName) {
        this.bName = bName;
    }

    public String getBTitle() {
        return bTitle;
    }

    public void setBTitle(String bTitle) {
        this.bTitle = bTitle;
    }

    public String getBContent() {
        return bContent;
    }

    public void setBContent(String bContent) {
        this.bContent = bContent;
    }

    public Timestamp getBDate() {
        return bDate;
    }

    public void setBDate(Timestamp bDate) {
        this.bDate = bDate;
    }

    public int getBHit() {
        return bHit;
    }

    public void setBHit(int bHit) {
        this.bHit = bHit;
    }

    public int getBGroup() {
        return bGroup;
    }

    public void setBGroup(int bGroup) {
        this.bGroup = bGroup;
    }

    public int getBStep() {
        return bStep;
    }

    public void setBStep(int bStep) {
        this.bStep = bStep;
    }

    public int getBIndent() {
        return bIndent;
    }

    public void setBIndent(int bIndent) {
        this.bIndent = bIndent;
    }

    public boolean isReply() {
        return bStep > 0;
    }


    public int getbid() { return getBId(); }

    public String getbName() { return getBName(); }

    public String getbTitle() { return getBTitle(); }

    public String getbContent() { return getBContent(); }

    public Timestamp getbDate() { return getBDate(); }

    public int getbHit() { return getBHit(); }

    public int getbGroup() { return getBGroup(); }

    public int getbStep() { return getBStep(); }

    public int getbIndent() { return getBIndent(); }
}
