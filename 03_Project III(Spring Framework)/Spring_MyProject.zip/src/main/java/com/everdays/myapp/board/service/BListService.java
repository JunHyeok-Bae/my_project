package com.everdays.myapp.board.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.ui.Model;

import com.everdays.myapp.board.dao.BDao;
import com.everdays.myapp.board.dto.BDto;

public class BListService implements BService {

    @Override
    public void execute(Model model) {
        BDao dao = new BDao();
        List<BDto> all = dao.list(); // ��ü �Խñ�

        List<BDto> questions = new ArrayList<>(); // ������ ������ ����Ʈ

        for (BDto dto : all) {
            if (dto.getBStep() == 0) {
                questions.add(dto);
            }
        }

        model.addAttribute("list", questions);
    }
}
