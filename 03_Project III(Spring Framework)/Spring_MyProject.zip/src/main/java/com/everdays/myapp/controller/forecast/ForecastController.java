package com.everdays.myapp.controller.forecast;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.everdays.myapp.forecast.model.DepressionVO;
import com.everdays.myapp.forecast.model.ElderlyRateSummaryVO;
import com.everdays.myapp.forecast.model.PopulationVO;
import com.everdays.myapp.forecast.service.DepressionService;
import com.everdays.myapp.forecast.service.ElderlyRateService;
import com.everdays.myapp.forecast.service.PopulationService;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class ForecastController {

    @Autowired
    private DepressionService depressionService;
    


    @GetMapping("/forecast/depression")
    public String showDepression(
            @RequestParam(required = false, defaultValue = "2025") int startYear, 
            @RequestParam(required = false, defaultValue = "2070") int endYear,
            Model model) {
        List<DepressionVO> depressionDataList = depressionService.getDepressionDataByYearRange(startYear, endYear);
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            String depressionDataJson = objectMapper.writeValueAsString(depressionDataList);
            model.addAttribute("depressionDataJson", depressionDataJson);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "forecast_depression"; 
    }

    
 // AJAX ��û�� ���� JSON �����͸� ��ȯ�ϴ� �޼���
    @GetMapping("/forecast/depression/data")
    @ResponseBody
    public List<DepressionVO> getDepressionData(
            @RequestParam(required = false, defaultValue = "2025") int startYear, 
            @RequestParam(required = false, defaultValue = "2070") int endYear) {
        return depressionService.getDepressionDataByYearRange(startYear, endYear);
    }
    
    
    @Autowired
    private ElderlyRateService elderlyRateService;
    
 // ���� ��Ʈ: ���ų��� ���� �����͸� �����ִ� ������ (�� ����)
    @GetMapping("/forecast/depression/doughnut")
    public String showDoughnutData(
            @RequestParam(required = false, defaultValue = "2000") int year,
            Model model) {
        // ���� ���� �����͸� ��ȸ
        ElderlyRateSummaryVO summary = elderlyRateService.getElderlyRateDataByYear(year);
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            String summaryJson = objectMapper.writeValueAsString(summary);
            model.addAttribute("elderlyRateSummaryJson", summaryJson);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "forecast_depression_doughnut";
    }
    
    // AJAX: ���� ��Ʈ �����͸� JSON���� ��ȯ
    @GetMapping("/forecast/depression/doughnutData")
    @ResponseBody
    public ElderlyRateSummaryVO getDoughnutData(
            @RequestParam(required = false, defaultValue = "2000") int year) {
        return elderlyRateService.getElderlyRateDataByYear(year);
    }
    
    @Autowired
    private PopulationService populationService;

    // ������ ������: model�� JSON ���ڿ� ��Ƽ� forecast_population.jsp�� ����
    @GetMapping("/forecast/population")
    public String showPopulation(
            @RequestParam(required = false, defaultValue = "2025") int startYear,
            @RequestParam(required = false, defaultValue = "2070") int endYear,
            @RequestParam(required = false) List<String> regions,
            Model model) {
    	
    	if (regions == null || regions.isEmpty()) {
            regions = new ArrayList<String>();
            regions.add("����");
        }
        List<PopulationVO> populationDataList = populationService.getPopulationData(startYear, endYear, regions);
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            String populationDataJson = objectMapper.writeValueAsString(populationDataList);
            model.addAttribute("populationDataJson", populationDataJson);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "forecast_population";  // InternalResourceViewResolver�� /WEB-INF/views/forecast_population.jsp�� ã���ϴ�.
    }

    // AJAX ��û: JSON �����͸� ��ȯ�ϴ� ��������Ʈ (URL�� /forecast/population/data �� ����)
    @GetMapping("/forecast/population/data")
    @ResponseBody
    public List<PopulationVO> getPopulationData(
            @RequestParam(required = false, defaultValue = "2025") int startYear,
            @RequestParam(required = false, defaultValue = "2070") int endYear,
            @RequestParam(required = false) List<String> regions) {
    	System.out.println("Received regions: " + regions);
        return populationService.getPopulationData(startYear, endYear, regions);
    }


    
    @RequestMapping("/forecast")
    public String showForecastOverview() {
        // forecast_overview.jsp�� ��ȯ
        return "forecast_overview";
    }
}


