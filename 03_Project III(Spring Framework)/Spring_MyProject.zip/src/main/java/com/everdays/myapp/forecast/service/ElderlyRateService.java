package com.everdays.myapp.forecast.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.everdays.myapp.forecast.dao.ElderlyRateDAO;
import com.everdays.myapp.forecast.model.ElderlyRateSummaryVO;

@Service
public class ElderlyRateService {

    @Autowired
    private ElderlyRateDAO elderlyRateDAO;
    
    public ElderlyRateSummaryVO getElderlyRateDataByYear(int year) {
        return elderlyRateDAO.getElderlyRateDataByYear(year);
    }
}
