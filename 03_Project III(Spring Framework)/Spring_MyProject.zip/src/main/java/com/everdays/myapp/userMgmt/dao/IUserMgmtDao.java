package com.everdays.myapp.userMgmt.dao;

import com.everdays.myapp.userMgmt.dto.UserMgmtDto;

public interface IUserMgmtDao {

    int USER_LOGIN_SUCCESS = 1;
    int USER_LOGIN_FAIL = 0;
    int USER_NOT_FOUND = -1;

    void join(UserMgmtDto user);
    int loginCheck(String userId, String password);

    UserMgmtDto findIdByEmail(String name, String email);
    UserMgmtDto findIdByPhone(String name, String phone);

    UserMgmtDto findPwByEmail(String userId, String name, String email);
    UserMgmtDto findPwByPhone(String userId, String name, String phone);

    void updatePassword(String userId, String newPassword);

    UserMgmtDto getMember(String userId);


    int countByUserId(String userId);
    int countByName(String name);
    int countByPhone(String phone);
    int countByEmail(String email);
}
