package com.everdays.myapp.controller.board;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.everdays.myapp.board.dao.BDao;
import com.everdays.myapp.board.dto.BDto;
import com.everdays.myapp.board.service.BContentService;
import com.everdays.myapp.board.service.BDeleteService;
import com.everdays.myapp.board.service.BModifyService;
import com.everdays.myapp.board.service.BReplyModifyService;
import com.everdays.myapp.board.service.BReplyModifyViewService;
import com.everdays.myapp.board.service.BReplyService;
import com.everdays.myapp.board.service.BService;
import com.everdays.myapp.board.service.BWriteService;

@Controller
public class BController {

    BService service = null;

    @RequestMapping("/list")
    public String list(HttpServletRequest request, Model model) {
        System.out.println("list()");

        String pageParam = request.getParameter("page");
        int page = 1;
        if (pageParam != null && !pageParam.isEmpty()) {
            try {
                page = Integer.parseInt(pageParam);
                if (page < 1) page = 1;
            } catch (NumberFormatException e) {
                page = 1;
            }
        }

        int itemsPerPage = 10;
        int startRow = (page - 1) * itemsPerPage;

        BDao dao = new BDao();
        ArrayList<BDto> list = dao.list(startRow, itemsPerPage);
        int totalCount = dao.getTotalCount();

        model.addAttribute("list", list);
        model.addAttribute("page", page);
        model.addAttribute("itemsPerPage", itemsPerPage);
        model.addAttribute("totalCount", totalCount);

        return "board/list";
    }

    @RequestMapping("/write_view")
    public String write_view(HttpServletRequest request, Model model) {
        System.out.println("write_view()");

        Object user = request.getSession().getAttribute("user");
        if (user == null) {
            return "redirect:/userMgmt/login";
        }

        String bId = request.getParameter("bId");
        if (bId != null && !bId.isEmpty()) {
            BDao dao = new BDao();
            BDto dto = dao.contentView(bId);

            model.addAttribute("bId", bId);
            model.addAttribute("bTitle", dto.getBTitle());
            model.addAttribute("bContent", dto.getBContent());
        }

        return "board/write_view";
    }

    @RequestMapping("/write")
    public String write(HttpServletRequest request, Model model) {
        System.out.println("write()");
        model.addAttribute("request", request);
        service = new BWriteService();
        service.execute(model);
        return "redirect:/list";
    }

    @RequestMapping("/content_view")
    public String content_view(HttpServletRequest request, Model model) {
        System.out.println("content_view()");
        model.addAttribute("request", request);
        service = new BContentService();
        service.execute(model);
        return "board/content_view";
    }

    @RequestMapping("/modify_view")
    public String modify_view(HttpServletRequest request, Model model) {
        System.out.println("modify_view()");
        model.addAttribute("request", request);
        service = new BReplyModifyViewService(); // ���� reply ���� �� ��Ȱ��
        service.execute(model);
        return "board/reply_modify";
    }

    @RequestMapping(value = "/modify", method = RequestMethod.POST)
    public String modify(HttpServletRequest request, Model model) {
        System.out.println("modify()");
        model.addAttribute("request", request);
        service = new BModifyService();
        service.execute(model);
        return "redirect:/list";
    }

    @RequestMapping("/reply")
    public String reply(HttpServletRequest request, Model model) {
        System.out.println("reply()");
        model.addAttribute("request", request);
        service = new BReplyService();
        service.execute(model);
        String redirectId = request.getParameter("bGroup");
        return "redirect:/content_view?bId=" + redirectId;
    }

    @RequestMapping("/delete")
    public String delete(HttpServletRequest request, Model model) {
        System.out.println("delete()");
        model.addAttribute("request", request);
        service = new BDeleteService();
        service.execute(model);
        return "redirect:/list";
    }

    @RequestMapping("/reply_modify_view")
    public String reply_modify_view(HttpServletRequest request, Model model) {
        System.out.println("reply_modify_view()");
        model.addAttribute("request", request);
        service = new BReplyModifyViewService();
        service.execute(model);
        return "board/reply_modify";
    }

    @RequestMapping(value = "/reply_modify", method = RequestMethod.POST)
    public String reply_modify(HttpServletRequest request, Model model) {
        System.out.println("reply_modify()");
        model.addAttribute("request", request);
        service = new BReplyModifyService();
        service.execute(model);
        String bGroup = request.getParameter("bGroup");
        return "redirect:/content_view?bId=" + bGroup;
    }
}
