document.addEventListener("DOMContentLoaded", function () {
  const slides = document.querySelectorAll(".carousel-slide");
  const progressLine = document.querySelector(".progress-line");
  const indicators = document.querySelectorAll(".indicator");
  const prevBtn = document.createElement("button");
  const nextBtn = document.createElement("button");
  const menuButton = document.querySelector(".m_nav img"); // 햄버거 버튼
  const menuBox = document.querySelector(".m_nav_box"); // 햄버거 메뉴 박스
  let currentIndex = 0;
  let intervalId;
  let isManualSlide = false;
  let isMenuOpen = false;

  // 🔹 `< >` 버튼 생성 및 추가
  prevBtn.classList.add("carousel-prev");
  nextBtn.classList.add("carousel-next");
  prevBtn.innerHTML = "&#10094;";
  nextBtn.innerHTML = "&#10095;";
  document.querySelector(".carousel-container").appendChild(prevBtn);
  document.querySelector(".carousel-container").appendChild(nextBtn);

  function setFixedIndicatorSpacing() {
    indicators.forEach((indicator) => {
      indicator.style.marginRight = "150px";
    });
  }

  function updateProgressLine(index) {
    const activeIndicator = indicators[index];
    const start = activeIndicator.offsetLeft + activeIndicator.offsetWidth / 2;
    progressLine.style.transition = "width 0s, left 0s";
    progressLine.style.left = `${start}px`;
    progressLine.style.width = `0px`;
    setTimeout(() => {
      progressLine.style.transition = "width 2s ease-in-out";
      progressLine.style.width = `13%`;
    }, 100);
  }

  function showSlide(index) {
    slides.forEach((slide, i) => {
      slide.style.opacity = i === index ? "1" : "0";
    });

    indicators.forEach((indicator, i) => {
      indicator.classList.toggle("active", i === index);
    });

    updateProgressLine(index);
  }

  function autoSlide() {
    if (!isManualSlide) {
      currentIndex = (currentIndex + 1) % slides.length;
      showSlide(currentIndex);
    }
  }

  function resumeAutoSlide() {
    isManualSlide = false;
    clearInterval(intervalId);
    intervalId = setInterval(autoSlide, 4000);
  }

  prevBtn.addEventListener("click", function () {
    isManualSlide = true;
    currentIndex = (currentIndex - 1 + slides.length) % slides.length;
    showSlide(currentIndex);
    resumeAutoSlide();
  });

  nextBtn.addEventListener("click", function () {
    isManualSlide = true;
    currentIndex = (currentIndex + 1) % slides.length;
    showSlide(currentIndex);
    resumeAutoSlide();
  });

  function initializeCarousel() {
    setFixedIndicatorSpacing();
    showSlide(currentIndex);
    intervalId = setInterval(autoSlide, 4000);
    prevBtn.style.display = "block";
    nextBtn.style.display = "block";
  }

  initializeCarousel();

  const circle = document.querySelector(".circle");
  setTimeout(() => {
    circle.style.opacity = "1";
    circle.style.transform = "translate(-50%, -50%) scale(1.5)";
  }, 1000);

  let isScrolling = false;
  window.addEventListener("wheel", function (event) {
    if (isScrolling) return;
    if (event.deltaY > 0) {
      isScrolling = true;
      document.querySelector(".services").scrollIntoView({
        behavior: "smooth",
      });
      setTimeout(() => {
        isScrolling = false;
      }, 1000);
    }
  });

  window.addEventListener("keydown", function (event) {
    if (event.key === "ArrowDown" && !isScrolling) {
      isScrolling = true;
      document.querySelector(".services").scrollIntoView({
        behavior: "smooth",
      });
      setTimeout(() => {
        isScrolling = false;
      }, 1000);
    }
  });

  const buttons = document.querySelectorAll(".service-button");
  buttons.forEach((button) => {
    button.addEventListener("click", function () {
      const targetPage = this.getAttribute("data-link");
      if (targetPage) {
        window.location.href = targetPage;
      }
    });
  });

  // 캐러셀이 먼저 실행된 후 AOS 초기화
  setTimeout(() => {
    AOS.init({
      duration: 800,  // 애니메이션 지속 시간 (ms)
      easing: "ease-in-out",  // 부드러운 가속 효과
      once: true,  // 한 번만 실행 (스크롤 다시 올려도 재실행 X)
    });
  }, 500);  // 500ms 지연 후 AOS 실행
});
