document.addEventListener("DOMContentLoaded", function () {
    const signupForm = document.querySelector("form");
    const requiredFields = document.querySelectorAll("input[required], select[required]");
    const passwordInput = document.getElementById("password1");
    const confirmPasswordInput = document.getElementById("password2");
    const requiredCheckboxes = document.querySelectorAll("input[required][type='checkbox']");
    const emailInput = document.getElementById("email");
    const phone2 = document.querySelector("input[name='phone2']");
    const phone3 = document.querySelector("input[name='phone3']");
    const agreeAll = document.getElementById("agree_all");

    // 비밀번호 정규식 검사 함수
    function isValidPasswordFormat(pw) {
        const pattern = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[^a-zA-Z0-9]).{10,14}$/;
        return pattern.test(pw);
    }

    signupForm.addEventListener("submit", function (event) {
        let isValid = true;

        // 필수 입력 필드 검사
        for (let field of requiredFields) {
            if (!field.value.trim()) {
                field.reportValidity();
                field.focus();
                isValid = false;
                break;
            }
        }

        // 비밀번호 길이 및 형식 검증
        if (isValid && !isValidPasswordFormat(passwordInput.value)) {
            alert("비밀번호는 10~14자 영문 + 숫자 + 특수문자 조합이어야 합니다.");
            passwordInput.focus();
            isValid = false;
        }

        // 비밀번호 일치 확인
        if (isValid && passwordInput.value !== confirmPasswordInput.value) {
            alert("입력한 비밀번호가 서로 일치하지 않습니다. 다시 확인해주세요.");
            confirmPasswordInput.focus();
            isValid = false;
        }

        // 필수 약관 확인
        if (isValid) {
            const allChecked = Array.from(requiredCheckboxes).every(cb => cb.checked);
            if (!allChecked) {
                alert("필수 약관에 동의해야 회원가입이 가능합니다.");
                isValid = false;
            }
        }

        // 검증 실패 시 폼 제출 방지
        if (!isValid) {
            event.preventDefault();
            return;
        }
        // 검증 성공 시 event.preventDefault()를 호출하지 않으므로,
        // 폼은 자연스럽게 서버로 전송됩니다.
    });

    // 입력 중 에러 스타일 제거
    requiredFields.forEach(field => {
        field.addEventListener("input", () => {
            field.classList.remove("error-border");
        });
    });

    // 휴대폰 포커스 자동 이동
    phone2.addEventListener("input", () => {
        if (phone2.value.length >= 4) phone3.focus();
    });

    phone3.addEventListener("input", () => {
        if (phone3.value.length >= 4) emailInput.focus();
    });

    // 전체 약관 동의 체크 연동
    if (agreeAll) {
        agreeAll.addEventListener("change", () => {
            requiredCheckboxes.forEach(cb => cb.checked = agreeAll.checked);
        });

        requiredCheckboxes.forEach(cb => {
            cb.addEventListener("change", () => {
                agreeAll.checked = Array.from(requiredCheckboxes).every(cb => cb.checked);
            });
        });
    }
});
