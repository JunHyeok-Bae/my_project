document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.querySelector("form");
    const usernameInput = document.getElementById("username");
    const passwordInput = document.getElementById("password");

    loginForm.addEventListener("submit", function (event) {
        let isValid = true;

        // 🛑 아이디 입력 확인
        if (!usernameInput.value.trim()) {
            usernameInput.reportValidity(); // 기본 HTML 말풍선 경고
            usernameInput.focus(); // 🚨 포커스 이동
            isValid = false;
        }

        // 🛑 비밀번호 입력 확인
        if (isValid && !passwordInput.value.trim()) {
            passwordInput.reportValidity(); // 기본 HTML 말풍선 경고
            passwordInput.focus(); // 🚨 포커스 이동
            isValid = false;
        }

        // 🚨 검증 실패 시 폼 제출 차단
        if (!isValid) {
            event.preventDefault();
            return;
        }

        // ✅ 모든 검증 통과 후 로그인 처리
        event.preventDefault(); // 기본 폼 제출 방지
        alert("✅ 로그인 성공! 메인 페이지로 이동합니다.");
        window.location.href = "index.html"; // 메인 페이지로 이동
    });
});
