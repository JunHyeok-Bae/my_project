document.addEventListener("DOMContentLoaded", function () {
    // 요소 가져오기
    const form = document.querySelector("form"); // 폼 요소
    const nameInput = document.getElementById("name"); // 이름 입력란
    const emailRadio = document.getElementById("email-radio");
    const phoneRadio = document.getElementById("phone-radio");
    const emailFields = document.getElementById("email-fields"); // 이메일 입력란
    const phoneFields = document.getElementById("phone-fields"); // 휴대폰 입력란
    const emailInput = document.getElementById("email"); // 이메일 입력 필드
    const phoneMiddle = document.getElementById("phone-middle"); // 휴대폰 가운데 자리
    const phoneLast = document.getElementById("phone-last"); // 휴대폰 마지막 자리

    // 🔹 라디오 버튼 변경 시 실행할 함수 (UI 토글)
    function toggleFields() {
        if (emailRadio.checked) {
            emailFields.style.display = "block";
            phoneFields.style.display = "none";
        } else if (phoneRadio.checked) {
            emailFields.style.display = "none";
            phoneFields.style.display = "block";
        }
    }

    // 🔹 입력 필드 자동 포커스 이동 (4자리 입력하면 다음 필드로)
    phoneMiddle.addEventListener("input", function () {
        if (this.value.length >= 4) {
            phoneLast.focus();
        }
    });

    phoneLast.addEventListener("input", function () {
        if (this.value.length >= 4) {
            document.querySelector(".submit-btn").focus();
        }
    });

    // 🔹 폼 제출 이벤트 (검증 추가)
    form.addEventListener("submit", function (event) {
        let isValid = true; // 검증 통과 여부

        // 🛑 이름 필수 입력 검증
        if (!nameInput.value.trim()) {
            nameInput.reportValidity();
            nameInput.focus();
            isValid = false;
        }

        // 🛑 이메일 방식 선택 시 이메일 입력 확인
        if (isValid && emailRadio.checked && !emailInput.value.trim()) {
            emailInput.reportValidity();
            emailInput.focus();
            isValid = false;
        }

        // 🛑 휴대폰 방식 선택 시 번호 2개 입력 확인
        if (isValid && phoneRadio.checked) {
            if (!phoneMiddle.value.trim() || phoneMiddle.value.length !== 4) {
                phoneMiddle.setCustomValidity("휴대폰 중간 번호(4자리)를 입력하세요.");
                phoneMiddle.reportValidity();
                phoneMiddle.focus();
                isValid = false;
            } else if (!phoneLast.value.trim() || phoneLast.value.length !== 4) {
                phoneLast.setCustomValidity("휴대폰 마지막 번호(4자리)를 입력하세요.");
                phoneLast.reportValidity();
                phoneLast.focus();
                isValid = false;
            }
        }

        // 🚨 검증 실패 시 폼 제출 차단
        if (!isValid) {
            event.preventDefault();
            return;
        }

        // ✅ 모든 검증 통과 후 아이디 찾기 결과 페이지로 이동
        alert("✅ 아이디 찾기 성공! 결과 페이지로 이동합니다.");
    });

    // 라디오 버튼 클릭 시 이벤트 추가
    emailRadio.addEventListener("change", toggleFields);
    phoneRadio.addEventListener("change", toggleFields);

    // 페이지 로드 시 초기 상태 설정
    toggleFields();
});
