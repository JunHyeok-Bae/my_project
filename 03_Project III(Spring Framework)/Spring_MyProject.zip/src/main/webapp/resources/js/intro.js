document.addEventListener("DOMContentLoaded", function () {
    AOS.init({
      duration: 800,  // 애니메이션 지속 시간 (ms)
      easing: "ease-in-out",  // 부드러운 가속 효과
      once: false,  // 한 번만 실행 (스크롤 다시 올려도 재실행 X)
    });
  });
  