function checkPasswordMatch() {
    let password = document.getElementById("newPassword").value.trim();
    let confirmPassword = document.getElementById("confirmPassword").value.trim();
    let button = document.getElementById("changePasswordBtn");

    if (password !== "" && confirmPassword !== "" && password === confirmPassword) {
        button.disabled = false;
        button.classList.add("active");
        button.style.cursor = "pointer";
    } else {
        button.disabled = true;
        button.classList.remove("active");
        button.style.cursor = "not-allowed";
    }
}

// 🔹 변경 버튼 클릭 시 로그인 페이지로 이동
function redirectToLogin() {
    let password = document.getElementById("newPassword").value.trim();
    let confirmPassword = document.getElementById("confirmPassword").value.trim();

    if (password === "" || confirmPassword === "") {
        alert("비밀번호를 입력해주세요.");
        return;
    }

    if (password !== confirmPassword) {
        alert("비밀번호가 일치하지 않습니다.");
        return;
    }

    alert("비밀번호 변경이 완료되었습니다.");
    window.location.href = "login.html"; // 🔹 로그인 페이지로 이동
}
