document.addEventListener("DOMContentLoaded", function () {
  const menuButton = document.querySelector(".m_nav img");       // 햄버거 버튼
  const menuBox = document.querySelector(".m_nav_box");          // 메뉴 전체 박스
  const leftSidebar = document.querySelector(".left_side_bar");  // 우측 슬라이드 메뉴
  const navBg = document.querySelector(".nav_bg");               // 어두운 배경
  const prevBtn = document.querySelector(".carousel-prev");
  const nextBtn = document.querySelector(".carousel-next");

  function hideCarouselButtons() {
    if (prevBtn) prevBtn.style.display = "none";
    if (nextBtn) nextBtn.style.display = "none";
  }

  function showCarouselButtons() {
    if (prevBtn) prevBtn.style.display = "block";
    if (nextBtn) nextBtn.style.display = "block";
  }

  // 햄버거 버튼 클릭 시 토글
  if (menuButton && menuBox) {
    menuButton.addEventListener("click", function (e) {
      e.stopPropagation();
      const isOpen = menuBox.classList.contains("active");
      menuBox.classList.toggle("active");

      if (isOpen) {
        showCarouselButtons();
      } else {
        hideCarouselButtons();
      }
    });
  }

  // 바깥 클릭 시 메뉴 닫힘
  document.addEventListener("click", function (event) {
    const isClickInside = menuBox.contains(event.target) || menuButton.contains(event.target);
    if (!isClickInside) {
      menuBox.classList.remove("active");
      showCarouselButtons();
    }
  });

  // 우측 메뉴 안쪽 클릭 시 propagation 차단
  if (leftSidebar) {
    leftSidebar.addEventListener("click", function (e) {
      e.stopPropagation();
    });
  }

  // 배경 클릭 시 닫힘
  if (navBg) {
    navBg.addEventListener("click", function (e) {
      e.stopPropagation();
      menuBox.classList.remove("active");
      showCarouselButtons();
    });
  }
});

// jQuery fallback (예전 코드 유지, 보호용)
$(function () {
  $(".m_nav").on("click", function (e) {
    e.stopPropagation();
    $(".m_nav_box").addClass("active");
    $(".carousel-prev, .carousel-next").hide();
  });

  $(".nav_bg").on("click", function (e) {
    e.stopPropagation();
    $(".m_nav_box").removeClass("active");
    $(".carousel-prev, .carousel-next").show();
  });

  $(".left_side_bar").on("click", function (e) {
    e.stopPropagation();
  });
});
