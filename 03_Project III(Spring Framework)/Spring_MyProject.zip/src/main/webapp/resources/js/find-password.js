document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("password-recovery-form");
    const emailRadio = document.getElementById("email-radio");
    const phoneRadio = document.getElementById("phone-radio");
    const emailFields = document.getElementById("email-fields");
    const phoneFields = document.getElementById("phone-fields");

    const userId = document.getElementById("user-id");
    const nameInput = document.getElementById("name");
    const emailInput = document.getElementById("email");
    const phoneMiddle = document.getElementById("phone-middle");
    const phoneLast = document.getElementById("phone-last");

    // 🔹 라디오 버튼 선택에 따라 입력 필드 전환
    function toggleFields() {
        emailFields.style.display = emailRadio.checked ? "block" : "none";
        phoneFields.style.display = phoneRadio.checked ? "block" : "none";
    }

    emailRadio.addEventListener("change", toggleFields);
    phoneRadio.addEventListener("change", toggleFields);
    toggleFields(); // 초기 실행

    // 🔹 입력 필드 자동 포커스 이동 (4자리 입력 시 다음 필드로)
    phoneMiddle.addEventListener("input", function () {
        if (this.value.length >= 4) phoneLast.focus();
    });

    // 🔹 폼 제출 시 유효성 검사
    window.validateForm = function () {
        let isValid = true; // 기본적으로 폼이 유효하다고 가정

        // 1️⃣ 아이디 필수 입력 확인
        if (userId.value.trim() === "") {
            showTooltip(userId, "아이디를 입력하세요");
            isValid = false;
        }

        // 2️⃣ 이름 필수 입력 확인
        if (nameInput.value.trim() === "") {
            showTooltip(nameInput, "이름을 입력하세요");
            isValid = false;
        }

        // 3️⃣ 이메일 또는 휴대폰 번호 필수 입력 확인
        if (emailRadio.checked) {
            if (emailInput.value.trim() === "") {
                showTooltip(emailInput, "이메일을 입력하세요");
                isValid = false;
            }
        } else if (phoneRadio.checked) {
            if (phoneMiddle.value.trim() === "" || phoneLast.value.trim() === "") {
                showTooltip(phoneMiddle, "휴대폰 번호를 입력하세요");
                isValid = false;
            }
        }

        // 🔹 유효성 검사 실패 시 폼 제출 막기
        if (!isValid) {
            return false; // 폼 제출 차단
        }

        // 🔹 성공 메시지 띄운 후 GET 방식으로 폼 제출
        alert("✅ 비밀번호 찾기 요청이 완료되었습니다.");
        form.submit(); // GET 방식으로 실제 제출
        return true;
    };

    // 🔹 입력 필드에 말풍선 오류 메시지 표시하는 함수
    function showTooltip(inputElement, message) {
        inputElement.setCustomValidity(message); // HTML5 말풍선 메시지
        inputElement.reportValidity(); // 즉시 표시
        inputElement.addEventListener("input", function () {
            inputElement.setCustomValidity(""); // 입력 시 말풍선 제거
        });
    }
});
