from flask import Flask, render_template, request, jsonify, Blueprint, g, redirect, url_for
import openai
from dotenv import load_dotenv
import requests
import os

load_dotenv()
openai.api_key = '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'
bp = Blueprint('chat', __name__, url_prefix='/chat')

@bp.route('/')
def index():
    if g.user:
        return render_template('chat/chat.html')
    else:
        return redirect(url_for('auth.login'))

@bp.route('/chat', methods=['POST'])
def gpt():
    # 클라이언트에서 보내는 메시지 받기
    data = request.get_json()
    user_message = data.get('message')

    # OpenAI API로 메시지 전송
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {openai.api_key}',
    }
    payload = {
        'model': 'gpt-3.5-turbo',
        'messages': [{'role': 'user', 'content': user_message}],
    }

    # OpenAI API로 요청 보내기
    response = requests.post('https://api.openai.com/v1/chat/completions', headers=headers, json=payload)

    if response.status_code == 200:
        data = response.json()
        return jsonify({'response': data['choices'][0]['message']['content']})
    else:
        return jsonify({'response': "Error: Unable to get a response from GPT."})