from flask import Blueprint, render_template

bp = Blueprint('introduction',__name__,url_prefix='/introduction')

@bp.route('/')
def introduction():
    return render_template('introduction.html')