from flask import Blueprint, render_template, jsonify, request, url_for, g, send_from_directory, current_app, abort, Response, flash
from pybo import db
from pybo.models import Depression, Original, Data
from werkzeug.utils import redirect
import pandas as pd
from io import BytesIO
from sqlalchemy import text

bp = Blueprint('service',__name__,url_prefix='/service')

@bp.route('/')
def service():
    return render_template('service/service.html')


@bp.route('/machine_learning', methods=['GET'])
def _machine_learning():
    if g.user:
        return render_template('service/machine_learning.html')
    else:
        return redirect(url_for('auth.login'))

@bp.route('/download', methods=['GET'])
def _download():
    if g.user:
        return render_template('service/download.html')
    else:
        return redirect(url_for('auth.login'))

@bp.route('/machine_learning_data', methods=['GET'])
def _machine_learning_data():
    depression = Depression.query.all()
    data = []

    for record in depression:
        data.append({
            'YEAR': record.YEAR,
            'ELDER_DEPRESSION': record.ELDER_DEPRESSION
        })
    return jsonify(data)

@bp.route('/original_data', methods=['GET'])
def _original_data():

    original = Original.query.all()
    data = []

    for record in original:
        data.append({
            'YEAR' : record.YEAR,
            'ELDER' : record.ELDER,
            'DEPRESSION_RATE' : record.DEPRESSION_RATE
        })
    return jsonify(data)


@bp.route('/data', methods=['GET'])
def get_data():

    data_records = Data.query.all()

    data = {}
    for record in data_records:
        year = record.YEAR
        elderly_population = record.ELDERLY_POPULATION
        elderly_population_rate = record.ELDERLY_POPULATION_RATE
        living_alone_elderly = record.LIVING_ALONE_ELDERLY
        living_alone_elderly_rate = record.LIVING_ALONE_ELDERLY_RATE

        data[year] = {
            'elderly_population': elderly_population,
            'elderly_population_rate': elderly_population_rate,
            'living_alone_elderly': living_alone_elderly,
            'living_alone_elderly_rate': living_alone_elderly_rate
        }

    return jsonify(data)

@bp.route('/download_excel_1')
def download_excel_1():
    query = text("SELECT Year, Elder_depression FROM Depression")

    data = db.session.execute(query).fetchall()

    if not data:
        return "다운로드할 데이터가 없습니다."
    df = pd.DataFrame(data, columns=["YEAR", "ELDER_DEPRESSION"])

    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl', mode='wb') as writer:
        df.to_excel(writer, index=False, sheet_name="Data")
    output.seek(0)

    file_size = len(output.getvalue())

    return Response(
        output.getvalue(),
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=depression.xlsx",
                 "Content-Length": str(file_size)}
    )


@bp.route('/download_excel_2')
def download_excel_2():
    query = text("SELECT Year, Elder, Depression_rate FROM Original_data")

    data = db.session.execute(query).fetchall()

    if not data:
        return "다운로드할 데이터가 없습니다."
    df = pd.DataFrame(data, columns=["YEAR", "ELDER", "DEPRESSION_RATE"])

    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl', mode='wb') as writer:
        df.to_excel(writer, index=False, sheet_name="Data")
    output.seek(0)

    file_size = len(output.getvalue())

    return Response(
        output.getvalue(),
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=data.xlsx",
                 "Content-Length": str(file_size)}
    )

@bp.route('/download_excel_3')
def download_excel_3():
    query = text("SELECT Year, Elderly_population, Elderly_population_rate, Living_alone_elderly, Living_alone_elderly_rate FROM Data")

    data = db.session.execute(query).fetchall()

    if not data:
        return "다운로드할 데이터가 없습니다."
    df = pd.DataFrame(data, columns=["YEAR", "Elderly_population", "Elderly_population_rate", "Living_alone_elderly", "Living_alone_elderly_rate"])

    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl', mode='wb') as writer:
        df.to_excel(writer, index=False, sheet_name="Data")
    output.seek(0)

    file_size = len(output.getvalue())

    return Response(
        output.getvalue(),
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=data.xlsx",
                 "Content-Length": str(file_size)}
    )
