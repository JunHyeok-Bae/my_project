// Initialize Swiper
const swiper = new Swiper('.swiper', {
  loop: true,
  speed: 600,
  autoplay: {
    delay: 5000,
  },
  slidesPerView: 'auto',
  pagination: {
    el: '.swiper-pagination',
    type: 'bullets',
    clickable: true,
  },
});

// Descriptions for each slide
const descriptions = [
  "독거노인 우울증 환자 수 예측: 독거노인의 우울증 문제는 심각한 사회적 이슈입니다. 2025~2070 우울증에 걸릴 것으로 예상되는 독거노인의 수를 시각화하여 제공합니다.",
  "데이터 다운로드: 2025~2070 독거노인 우울증 환자 수 예측 데이터와 예측 데이터에 사용된 데이터들을 제공합니다.",
  "봉사 신청: 봉사 신청을 통해 독거노인들의 외로움과 우울감을 덜어주세요.",
  "도움 요청: 도움이 필요한 독거노인들이 직접 도움을 요청할 수 있습니다."
];

// Update description when slide changes
swiper.on('slideChange', function () {
  const activeIndex = swiper.activeIndex % descriptions.length; // Get active slide index
  const descriptionElement = document.getElementById('project-description');

  // Clear previous description and update it
  descriptionElement.innerHTML = `
    <li><strong>독거노인 우울증 환자 수 예측</strong>: ${descriptions[activeIndex]}</li>
    <li><strong>데이터 다운로드</strong>: 2025~2070 독거노인 우울증 환자 수 예측 데이터와 예측 데이터에 사용된 데이터들을 제공합니다.</li>
    <li><strong>봉사 신청</strong>: 봉사 신청을 통해 독거노인들의 외로움과 우울감을 덜어주세요.</li>
    <li><strong>도움 요청</strong>: <a href="#">도움이 필요한 독거노인들이 직접 도움을 요청할 수 있습니다.</a></li>
  `;
});
