package com.java_edu;

public class select_sort {

	public static void main(String[] args) {
		int[] a = new int[10];
		a[0]=11;
		a[1]=2;
		a[2]=15;
		a[3]=40;
		a[4]=7;
		a[5]=13;
		a[6]=5;
		a[7]=10;
		a[8]=19;
		a[9]=20;
		
		int i = 0;

		while (i<a.length) {

		System.out.println(a[i]); 
		i++;
		

	}


}
}
