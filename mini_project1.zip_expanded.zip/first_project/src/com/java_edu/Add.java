package com.java_edu;

public class Add {

	public static void main(String[] args) {
		int x, y, sum;
		x = 100;
		y = 200;
		
		sum = x + y;
		System.out.println(sum);

	}

}
