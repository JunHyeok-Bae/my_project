package com.java_edu;

public class exmple {

	public static void main(String[] args) {
		String strVar1="배준혁";
		String strVar2="배준혁";
		
		if(strVar1==strVar2) {
			System.out.println("strVar1과 strVar2는 참조가 같음");
		}else {
			System.out.println("strVar1과 strVar2는 참조가 다름");
		}
		
		if(strVar1.contentEquals(strVar2)) {
			System.out.println("strVar1과 strVar2는 문자열이 같음");
		}
		
		String strVar3 =new String("배준혁");
		String strVar4 =new String("배준혁");
		
		if(strVar3 ==strVar4) {
			System.out.println("strVar3과 strVar4는 참조가 같음");
		}else {
			System.out.println("strVar3과 strVar4는 참조가 다름");
		}
		
		if(strVar3.contentEquals(strVar4)) {
			System.out.println("strVar3과 strVar4는 문자열이 같음");
		}
		

	}

}
