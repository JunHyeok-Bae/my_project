package com.java_edu;

import java.util.Scanner;

public class SmartPhoneMain {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		SmartPhone smartPhone = new SmartPhone();
		
        Addr addr1 = smartPhone.inputAddrData(scanner);
        smartPhone.addAddr(smartPhone.ads, addr1);
        System.out.println("데이터가 저장되었습니다.(1)");

        Addr addr2 = smartPhone.inputAddrData(scanner);
        smartPhone.addAddr(smartPhone.ads, addr2);
        System.out.println("데이터가 저장되었습니다.(2)");


		while(true) {
			System.out.println("주소관리 메뉴------------");
			System.out.println("1. 연락처 등록");
			System.out.println("2. 모든 연락처 출력");
			System.out.println("3. 연락처 검색");
			System.out.println("4. 연락처 삭제");
			System.out.println("5. 연락처 수정");
			System.out.println("6. 프로그램 종료");
			System.out.println("---------------------");
			
			int choice = scanner.nextInt();
			scanner.nextLine();
	
		
		switch (choice) {
		case 1:
			Addr newAddr = smartPhone.inputAddrData(scanner);
            smartPhone.addAddr(smartPhone.ads, newAddr);
            System.out.println("연락처가 추가되었습니다.");
            break;

        case 2:
            smartPhone.printAllAddr();
            break;

        case 3:
            System.out.print("검색할 이름을 입력하세요: ");
            String searchName = scanner.nextLine();
            smartPhone.searchAddr(searchName);
            break;

        case 4:
            System.out.print("삭제할 이름을 입력하세요: ");
            String deleteName = scanner.nextLine();
            smartPhone.deleteAddr(deleteName);
            break;

        case 5:
            System.out.print("수정할 이름을 입력하세요: ");
            String editName = scanner.nextLine();
            Addr editedAddr = smartPhone.inputAddrData(scanner);
            smartPhone.editAddr(editName, editedAddr);
            break;

        case 6:
            System.out.println("프로그램을 종료합니다.");
            System.exit(0);
            return;

        default:
            System.out.println("잘못된 입력입니다. 다시 시도하세요.");
            break;
    }
}

}}
		

		
		
		




