package com.java_edu;

import java.util.Scanner;

public class SmartPhone {
	Addr[] ads = new Addr[10];
	Scanner scanner = new Scanner(System.in);
	
	
	


public Addr inputAddrData(Scanner scanner){
	
	System.out.print("이름을 입력하세요: ");
	String name = scanner.nextLine();
	System.out.print("전화번호를 입력하세요: ");
	String phone = scanner.nextLine();
	System.out.print("이메일을 입력하세요: ");
	String email = scanner.nextLine();
	System.out.print("주소를 입력하세요: ");
	String address = scanner.nextLine();
	System.out.print("그룹(친구/가족)을 입력하세요: ");
	String group = scanner.nextLine();
	
	Addr inputAddr = new Addr(name, phone, email, address, group);
	
	return inputAddr;
}

public void addAddr(Addr[] ads, Addr addr) {
	boolean found = true;
	int i = 0 ;
	for(i=0; i<ads.length; i++) {
		if(ads[i]==null) {
			ads[i]= addr;
			found = false;
			break;
		}
		if(!found) {
			System.out.println("연락처가 가득 찼습니다.");
		}
	}
	
}
	

public void printAllAddr() {
	boolean found = false;
	for (Addr ad : ads) {
		if (ad!=null) {
		System.out.println("Name:"+ad.getName());
		System.out.println("Phone:"+ad.getPhone());
		System.out.println("Email:"+ad.getEmail());
		System.out.println("Address:"+ad.getAddress());
		System.out.println("Group: "+ad.getGroup());
		System.out.println();
		found = true;
	    if(!found) {
		System.out.println("연락처가 존재하지 않습니다.");
	}
		}
		
}
}
public void searchAddr(String name) {
	int i = 0 ;
	boolean found = false;
	for(i=0; i<ads.length; i++) {
		if(ads[i] != null && ads[i].getName().contentEquals(name)) {
			ads[i].printInfo();
			found = true;
			break;
			
		}if(!found) {
			System.out.println("연락처가 존재하지 않습니다.");
		}
	}


		
	
	}
public void deleteAddr(String name) {
	int i = 0 ;
	boolean found = false;
	for (i=0; i<ads.length; i++) {
		if (ads[i].getName().contentEquals(name)) {
			ads[i]=null;
			found = true;
			System.out.println("연락처가 삭제되었습니다.");
			break;
			
		}
	if(!found) {
		System.out.println("연락처가 존재하지 않습니다.");
			
		}
	}
	
	}

public void editAddr(String name, Addr newAddr) {
	int i = 0 ;
	boolean found = false;
	for (i=0; i<ads.length; i++) {
		if (ads[i] != null && ads[i].getName().contentEquals(name) ) {
			ads[i] = newAddr;
			found = true;
			System.out.println("연락처가 수정되었습니다.");
			break;
		}
		
	}
	    if(!found) {
		    System.out.println("연락처가 존재하지 않습니다.");
	}
			 
		 }
	 }
	
